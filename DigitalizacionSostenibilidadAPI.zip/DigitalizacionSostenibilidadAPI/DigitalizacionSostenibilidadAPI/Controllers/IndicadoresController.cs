﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using DigitalizacionSostenibilidadAPI.Data;
using DigitalizacionSostenibilidadAPI.Models;

namespace DigitalizacionSostenibilidadAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class IndicadoresController : ControllerBase
    {
        private readonly AppDbContext _context;

        public IndicadoresController(AppDbContext context)
        {
            _context = context;
        }

        // GET: api/indicadores
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Indicador>>> GetIndicadores(
            string? tipo,
            string? categoria,
            string? ambito)
        {
            var query = _context.Indicadores.AsQueryable();

            if (!string.IsNullOrEmpty(tipo))
                query = query.Where(i => i.Tipo == tipo);

            if (!string.IsNullOrEmpty(categoria))
                query = query.Where(i => i.Categoria == categoria);

            if (!string.IsNullOrEmpty(ambito))
                query = query.Where(i => i.Ambito == ambito);

            return await query.ToListAsync();
        }

        // GET: api/indicadores/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Indicador>> GetIndicador(int id)
        {
            var indicador = await _context.Indicadores.FindAsync(id);

            if (indicador == null)
                return NotFound();

            return indicador;
        }

        // GET: api/indicadores/resumen/tipo
        [HttpGet("resumen/tipo")]
        public async Task<ActionResult> GetResumenPorTipo()
        {
            var resumen = await _context.Indicadores
                .GroupBy(i => i.Tipo)
                .Select(g => new
                {
                    Tipo = g.Key,
                    Total = g.Count()
                })
                .ToListAsync();

            return Ok(resumen);
        }

        // GET: api/indicadores/resumen/categoria
        [HttpGet("resumen/categoria")]
        public async Task<ActionResult> GetResumenPorCategoria()
        {
            var resumen = await _context.Indicadores
                .GroupBy(i => i.Categoria)
                .Select(g => new
                {
                    Categoria = g.Key,
                    Total = g.Count()
                })
                .ToListAsync();

            return Ok(resumen);
        }

        // POST: api/indicadores
        [HttpPost]
        public async Task<ActionResult<Indicador>> PostIndicador(Indicador indicador)
        {
            _context.Indicadores.Add(indicador);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetIndicador), new { id = indicador.Id }, indicador);
        }

        // PUT: api/indicadores/5
        [HttpPut("{id}")]
        public async Task<IActionResult> PutIndicador(int id, Indicador indicador)
        {
            if (id != indicador.Id)
                return BadRequest();

            _context.Entry(indicador).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!_context.Indicadores.Any(e => e.Id == id))
                    return NotFound();
                else
                    throw;
            }

            return NoContent();
        }

        // DELETE: api/indicadores/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteIndicador(int id)
        {
            var indicador = await _context.Indicadores.FindAsync(id);

            if (indicador == null)
                return NotFound();

            _context.Indicadores.Remove(indicador);
            await _context.SaveChangesAsync();

            return NoContent();
        }
    }
}
